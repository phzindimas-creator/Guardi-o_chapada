GUARDIAN OF CHAPADA GAUCHA - ANDROID

Android-only configuration:
- English source code and configuration
- Landscape
- Fullscreen
- Touch controls
- No keyboard controls
- ARM64 APK
- GitHub Actions build

GitHub steps:
1. Put the Python file in the repository as main.py.
2. Put guardian_android_buildozer.spec in the repository as buildozer.spec.
3. Create .github/workflows/
4. Put build-apk-android.yml there as build-apk.yml.
5. Open Actions.
6. Run Build Android APK.
7. Download guardian-chapada-apk from Artifacts.
