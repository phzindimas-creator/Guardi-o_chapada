[app]
title = Guardian of Chapada Gaucha
package.name = guardiaochapada
package.domain = org.chapadagaucha
source.dir = .
source.include_exts = py,png,jpg,jpeg,wav,ogg,ttf
version = 1.0
requirements = python3,pygame
orientation = landscape
fullscreen = 1
android.api = 36
android.minapi = 24
android.ndk = 28c
android.ndk_api = 24
android.archs = arm64-v8a
android.accept_sdk_license = True
android.permissions =
p4a.bootstrap = sdl2

[buildozer]
log_level = 2
warn_on_root = 0
